
'use client';

import React, {
  createContext,
  useState,
  useContext,
  ReactNode,
  useMemo,
  useEffect,
} from 'react';
import { useUser as useFirebaseAuth, useFirestore, useDoc, useMemoFirebase } from '@/firebase';
import { doc, setDoc } from 'firebase/firestore';
import type { User as FirebaseUser } from 'firebase/auth';

interface User {
  name: string;
  email: string | null;
  uid: string;
  phone: string | null;
}

interface UserProfile {
  name: string;
  email: string | null;
  isPremium: boolean;
}

interface UserContextType {
  user: User | null;
  userProfile: UserProfile | null;
  isPremium: boolean;
  isLoading: boolean;
  upgrade: () => Promise<void>;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const { user: firebaseUser, isUserLoading } = useFirebaseAuth();
  const firestore = useFirestore();

  const userDocRef = useMemoFirebase(() => {
    if (firestore && firebaseUser) {
      return doc(firestore, 'users', firebaseUser.uid);
    }
    return null;
  }, [firestore, firebaseUser]);

  const { data: userProfile, isLoading: isProfileLoading } = useDoc<UserProfile>(userDocRef);

  const upgrade = async () => {
    if (firebaseUser && firestore) {
      const userDocRef = doc(firestore, 'users', firebaseUser.uid);
      await setDoc(userDocRef, { isPremium: true }, { merge: true });
    }
  };

  const user: User | null = useMemo(() => {
    if (firebaseUser) {
      return {
        uid: firebaseUser.uid,
        email: firebaseUser.email,
        name: userProfile?.name || firebaseUser.displayName || `User ${firebaseUser.uid.substring(0,5)}`,
        phone: firebaseUser.phoneNumber,
      };
    }
    return null;
  }, [firebaseUser, userProfile]);

  const value = useMemo(
    () => ({
      user,
      userProfile: userProfile ?? null,
      isPremium: userProfile?.isPremium ?? false,
      isLoading: isUserLoading || isProfileLoading,
      upgrade,
    }),
    [user, userProfile, isUserLoading, isProfileLoading]
  );

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
