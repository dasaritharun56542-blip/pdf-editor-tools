export const firebaseConfig = {
  "projectId": "studio-7269490791-22844",
  "appId": "1:814016643084:web:af4d1fb1e736391565ee29",
  "apiKey": "AIzaSyCGL0Av1j3agET9Xkxf2i7Kmfw8qVZwA9E",
  "authDomain": "studio-7269490791-22844.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "814016643084"
};
