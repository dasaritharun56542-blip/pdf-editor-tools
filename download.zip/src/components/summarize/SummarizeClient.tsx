
"use client";

import { useState } from 'react';
import { useUser } from '@/context/UserContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import Link from 'next/link';
import { FileUpload } from './FileUpload';
import { pdfSummarization } from '@/ai/flows/pdf-summarization';
import { Loader2, FileText, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function SummarizeClient() {
  const { user, isPremium, isLoading: isUserLoading } = useUser();
  const [file, setFile] = useState<File | null>(null);
  const [summary, setSummary] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleFileChange = (selectedFile: File | null) => {
    setFile(selectedFile);
    setSummary(null);
    setError(null);
  };

  const handleSubmit = async () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please upload a PDF file to summarize.",
        variant: "destructive",
      });
      return;
    }
    if (!isPremium) {
      toast({
        title: "Premium Feature",
        description: "Please upgrade to use the AI Summarizer.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setError(null);
    setSummary(null);

    try {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = async () => {
        const pdfDataUri = reader.result as string;
        const result = await pdfSummarization({ pdfDataUri });
        setSummary(result.summary);
      };
      reader.onerror = () => {
        throw new Error('Failed to read file.');
      };
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(`Failed to generate summary. ${errorMessage}`);
      toast({
        title: "Summarization Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (isUserLoading) {
    return (
      <div className="flex justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!user) {
    return (
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Please Log In</AlertTitle>
        <AlertDescription>
          You need to be logged in to use this feature. <Link href="/login?redirect=/summarize" className="font-bold text-primary hover:underline">Log in now</Link>.
        </AlertDescription>
      </Alert>
    );
  }

  if (!isPremium) {
    return (
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Premium Feature</AlertTitle>
        <AlertDescription>
          The AI Summarizer is a premium feature. <Link href="/pricing" className="font-bold text-primary hover:underline">Upgrade your plan</Link> to get access.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="space-y-6">
          <FileUpload onFileChange={handleFileChange} />
          
          <Button onClick={handleSubmit} disabled={isLoading || !file} className="w-full">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Summarizing...
              </>
            ) : (
              'Generate Summary'
            )}
          </Button>

          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {summary && (
            <div className="space-y-4 rounded-lg border bg-background p-4">
              <h3 className="flex items-center text-lg font-semibold">
                <FileText className="mr-2 h-5 w-5" />
                Document Summary
              </h3>
              <p className="whitespace-pre-wrap text-sm text-muted-foreground">{summary}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
