"use client";

import { useState, useCallback, ChangeEvent, DragEvent } from 'react';
import { UploadCloud, File, X } from 'lucide-react';

interface FileUploadProps {
  onFileChange: (file: File | null) => void;
}

export function FileUpload({ onFileChange }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);

  const handleFile = useCallback((file: File | null) => {
    if (file && file.type === 'application/pdf') {
      setFileName(file.name);
      onFileChange(file);
    } else {
      setFileName(null);
      onFileChange(null);
      // Optional: show a toast notification for invalid file type
    }
  }, [onFileChange]);

  const handleDragEnter = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    handleFile(file || null);
  };

  const handleFileSelect = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    handleFile(file || null);
  };
  
  const handleRemoveFile = () => {
    setFileName(null);
    onFileChange(null);
  };

  if (fileName) {
    return (
        <div className="flex h-48 w-full items-center justify-center rounded-lg border-2 border-dashed border-primary bg-primary/5 p-6 text-center">
            <div className="flex flex-col items-center gap-4">
                <File className="h-12 w-12 text-primary" />
                <p className="font-medium">{fileName}</p>
                <button onClick={handleRemoveFile} className="flex items-center gap-2 text-sm text-red-600 hover:text-red-800 font-semibold">
                    <X className="h-4 w-4" />
                    Remove file
                </button>
            </div>
        </div>
    )
  }

  return (
    <div
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      className={`relative flex h-48 w-full cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed transition-colors ${isDragging ? 'border-primary bg-primary/10' : 'border-border hover:border-primary/50'}`}
    >
      <input
        type="file"
        accept="application/pdf"
        className="absolute inset-0 h-full w-full opacity-0"
        onChange={handleFileSelect}
      />
      <div className="flex flex-col items-center gap-2 text-muted-foreground">
        <UploadCloud className="h-10 w-10" />
        <p className="font-semibold">Drag & drop your PDF here</p>
        <p className="text-sm">or</p>
        <p className="font-semibold text-primary">Click to select a file</p>
        <p className="text-xs mt-2">Maximum file size: 1GB</p>
      </div>
    </div>
  );
}
