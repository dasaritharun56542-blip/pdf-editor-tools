
"use client";

import { useState, useEffect } from 'react';
import Image from 'next/image';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Copy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { PlaceHolderImages } from '@/lib/placeholder-images';

interface PaymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onPaymentSuccess: () => Promise<void>;
  price: number;
  upiId: string;
}

export function PaymentModal({ open, onOpenChange, onPaymentSuccess, price, upiId }: PaymentModalProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();
  const qrCodeImage = PlaceHolderImages.find(p => p.id === 'qr-code-placeholder');

  useEffect(() => {
    if (open) {
      setIsProcessing(true);
      // In a real app, you would set up a webhook or a WebSocket listener.
      // Here, we simulate polling for payment confirmation.
      const paymentCheckInterval = setInterval(async () => {
        // Simulate a successful payment after a few seconds
        console.log("Checking for payment...");
        // This is where you would check your backend if the payment was successful
        // For this simulation, we'll just confirm it after a delay.
        clearInterval(paymentCheckInterval);
        await onPaymentSuccess();
        setIsProcessing(false);
        onOpenChange(false);
      }, 5000); // Check every 5 seconds, but we'll clear it on the first "success"

      return () => {
        clearInterval(paymentCheckInterval);
      };
    } else {
        setIsProcessing(false);
    }
  }, [open, onPaymentSuccess, onOpenChange]);


  const handleCopyToClipboard = () => {
    navigator.clipboard.writeText(upiId);
    toast({
      title: 'Copied to clipboard',
      description: 'UPI ID has been copied to your clipboard.',
    });
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center text-2xl font-bold">Complete Your Payment</DialogTitle>
          <DialogDescription className="text-center">
            Scan the QR code with your UPI app or use the UPI ID below.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-6 py-4">
            <div className="flex justify-center">
                {qrCodeImage && (
                    <Image
                        src={qrCodeImage.imageUrl}
                        alt="QR Code"
                        width={200}
                        height={200}
                        className="rounded-lg border p-2"
                        data-ai-hint={qrCodeImage.imageHint}
                    />
                )}
            </div>
            <div className="text-center">
                <p className="text-lg font-bold">Total Amount: ${price}</p>
            </div>
            <div className="space-y-2">
                <Label htmlFor="upi-id">Pay to UPI ID</Label>
                <div className="flex items-center gap-2">
                    <Input id="upi-id" value={upiId} readOnly />
                    <Button variant="outline" size="icon" onClick={handleCopyToClipboard}>
                        <Copy className="h-4 w-4" />
                        <span className="sr-only">Copy UPI ID</span>
                    </Button>
                </div>
            </div>
             {isProcessing && (
              <div className="flex flex-col items-center justify-center gap-2 text-center text-sm text-muted-foreground">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
                <span>Waiting for payment confirmation...</span>
                <span>This will happen automatically.</span>
              </div>
            )}
        </div>
        <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button variant="outline" onClick={() => onOpenChange(false)} className="w-full sm:w-auto">
                Cancel
            </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
