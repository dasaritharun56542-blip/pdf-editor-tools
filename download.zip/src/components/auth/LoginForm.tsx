
"use client";

import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/firebase';
import { sendSignInLinkToEmail } from 'firebase/auth';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, Mail } from 'lucide-react';

export function LoginForm() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isLinkSent, setIsLinkSent] = useState(false);
  
  const router = useRouter();
  const searchParams = useSearchParams();
  const auth = useAuth();
  const { toast } = useToast();

  const handleEmailSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);
    
    try {
      // The URL must be a part of the authorized domains in the Firebase console.
      const redirectUrl = searchParams.get('redirect') || '/dashboard';
      const actionCodeSettings = {
        url: `${window.location.origin}${redirectUrl}`,
        handleCodeInApp: true,
      };

      await sendSignInLinkToEmail(auth, email, actionCodeSettings);
      
      // Save the email locally to use it after the redirect
      window.localStorage.setItem('emailForSignIn', email);

      setIsLinkSent(true);
      toast({
        title: "Check your email",
        description: "A sign-in link has been sent to your email address.",
      });
    } catch (err: any) {
      console.error("Failed to send sign-in link", err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLinkSent) {
    return (
       <Alert>
        <Mail className="h-4 w-4" />
        <AlertTitle>Magic Link Sent!</AlertTitle>
        <AlertDescription>
          We've sent a sign-in link to <strong>{email}</strong>. Please check your inbox and click the link to log in.
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-6">
       {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Login Failed</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleEmailSignIn} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="email">Email Address</Label>
          <Input
            id="email"
            type="email"
            placeholder="your@email.com"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={isLoading}
          />
        </div>
        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? 'Sending Link...' : 'Send Sign-In Link'}
        </Button>
      </form>
    </div>
  );
}
