
"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/firebase';
import { sendSignInLinkToEmail } from 'firebase/auth';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, Mail } from 'lucide-react';

export function SignupForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isLinkSent, setIsLinkSent] = useState(false);

  const router = useRouter();
  const auth = useAuth();
  const { toast } = useToast();

  const handleSendLink = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      const actionCodeSettings = {
        url: `${window.location.origin}/dashboard`,
        handleCodeInApp: true,
      };

      await sendSignInLinkToEmail(auth, email, actionCodeSettings);
      
      // Save the email and name locally to create the user after they click the link
      window.localStorage.setItem('emailForSignIn', email);
      if (name) {
        window.localStorage.setItem('nameForSignUp', name);
      }

      setIsLinkSent(true);
      toast({
        title: "Check your email",
        description: "A verification link has been sent to your email address.",
      });
    } catch (err: any) {
      console.error("Failed to send sign-up link", err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLinkSent) {
    return (
       <Alert>
        <Mail className="h-4 w-4" />
        <AlertTitle>Verification Link Sent!</AlertTitle>
        <AlertDescription>
          We've sent a link to <strong>{email}</strong>. Please check your inbox and click the link to complete your signup.
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Signup Failed</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSendLink} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="name">Name (Optional)</Label>
          <Input
            id="name"
            placeholder="Your name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            disabled={isLoading}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email">Email Address</Label>
          <Input
            id="email"
            type="email"
            placeholder="your@email.com"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={isLoading}
          />
        </div>
        <Button type="submit" className="w-full" disabled={isLoading}>
          {isLoading ? 'Sending Link...' : 'Sign Up with Email Link'}
        </Button>
      </form>
    </div>
  );
}
