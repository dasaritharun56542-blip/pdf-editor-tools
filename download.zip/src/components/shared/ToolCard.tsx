
"use client";

import Link from 'next/link';
import { Card, CardContent } from '@/components/ui/card';
import { Lock } from 'lucide-react';
import type { Tool } from '@/lib/data';
import { useUser } from '@/context/UserContext';
import { useState } from 'react';
import { UpgradeModal } from './UpgradeModal';
import * as icons from 'lucide-react';
import { cn } from '@/lib/utils';

export function ToolCard(tool: Tool) {
  const { user, isPremium, isLoading } = useUser();
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  const isLocked = tool.premium && !isPremium;

  const handleClick = (e: React.MouseEvent) => {
    if (isLoading) {
      e.preventDefault();
      return;
    }
    if (isLocked) {
      e.preventDefault();
      setShowUpgradeModal(true);
    }
  };

  const IconComponent = icons[tool.icon as keyof typeof icons] as icons.LucideIcon;

  return (
    <>
      <Link href={isLocked ? '#' : tool.href} onClick={handleClick} className="h-full group relative">
        <Card 
          className={cn(
            "h-full transition-all duration-300 flex flex-col items-center justify-center p-6 text-center hover:shadow-lg hover:-translate-y-1 bg-card",
             isLocked ? 'bg-gray-100 cursor-not-allowed' : 'hover:border-primary'
          )}
        >
          <CardContent className="p-0 flex flex-col items-center gap-3">
            {IconComponent && <IconComponent className="h-10 w-10 shrink-0 text-primary" />}
            <h3 className="font-bold tracking-tight text-base text-card-foreground">{tool.title}</h3>
            <p className="text-xs text-muted-foreground">{tool.description}</p>
          </CardContent>
        </Card>
         {isLocked && (
            <div className="absolute top-2 right-2 rounded-full bg-gray-200 p-1.5">
              <Lock className="h-4 w-4 text-gray-500" />
            </div>
          )}
      </Link>
      <UpgradeModal open={showUpgradeModal} onOpenChange={setShowUpgradeModal} />
    </>
  );
}
