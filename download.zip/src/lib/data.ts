
export type NavLink = {
  label: string;
  href: string;
};

export const navLinks: NavLink[] = [
  { label: 'Home', href: '/' },
  { label: 'Tools', href: '/tools' },
  { label: 'Pricing', href: '/pricing' },
  { label: 'FAQ', href: '/faq' },
  { label: 'Contact', href: '/contact' },
];

export type Tool = {
  id: string;
  title: string;
  description: string;
  icon: string;
  href: string;
  premium: boolean;
};

export const tools: Tool[] = [
  {
    id: 'merge-pdf',
    title: 'Merge PDF',
    description: 'Combine multiple PDFs into one single document.',
    icon: 'Combine',
    href: '/tools',
    premium: false,
  },
  {
    id: 'split-pdf',
    title: 'Split PDF',
    description: 'Extract pages from a PDF or save each page as a separate PDF.',
    icon: 'Split',
    href: '/tools',
    premium: false,
  },
  {
    id: 'compress-pdf',
    title: 'Compress PDF',
    description: 'Reduce the file size of your PDF while optimizing for quality.',
    icon: 'FileMinus',
    href: '/tools',
    premium: false,
  },
  {
    id: 'summarize-pdf',
    title: 'Summarize PDF (AI)',
    description: 'Use AI to get a quick summary of your PDF document.',
    icon: 'BrainCircuit',
    href: '/summarize',
    premium: true,
  },
  {
    id: 'pdf-to-word',
    title: 'PDF to Word',
    description: 'Convert your PDFs to editable Word documents.',
    icon: 'FileText',
    href: '/tools',
    premium: true,
  },
  {
    id: 'word-to-pdf',
    title: 'Word to PDF',
    description: 'Convert Word documents to professional-looking PDFs.',
    icon: 'FileJson',
    href: '/tools',
    premium: false,
  },
  {
    id: 'pdf-to-jpg',
    title: 'PDF to JPG',
    description: 'Extract all images from a PDF or convert each page to JPG.',
    icon: 'FileImage',
    href: '/tools',
    premium: true,
  },
  {
    id: 'jpg-to-pdf',
    title: 'JPG to PDF',
    description: 'Convert JPG images to PDF in seconds. Adjust orientation and margins.',
    icon: 'ImageIcon',
    href: '/tools',
    premium: false,
  },
];
