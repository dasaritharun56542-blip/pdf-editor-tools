'use server';

/**
 * @fileOverview An AI agent that summarizes PDF documents.
 *
 * - pdfSummarization - A function that handles the PDF summarization process.
 * - PdfSummarizationInput - The input type for the pdfSummarization function.
 * - PdfSummarizationOutput - The return type for the pdfSummarization function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import wav from 'wav';

const PdfSummarizationInputSchema = z.object({
  pdfDataUri: z
    .string()
    .describe(
      'A PDF document as a data URI that must include a MIME type and use Base64 encoding. Expected format: \'data:<mimetype>;base64,<encoded_data>\'.' // Corrected format
    ),
});
export type PdfSummarizationInput = z.infer<typeof PdfSummarizationInputSchema>;

const PdfSummarizationOutputSchema = z.object({
  summary: z.string().describe('A summary of the PDF document.'),
});
export type PdfSummarizationOutput = z.infer<typeof PdfSummarizationOutputSchema>;

export async function pdfSummarization(input: PdfSummarizationInput): Promise<PdfSummarizationOutput> {
  return pdfSummarizationFlow(input);
}

const prompt = ai.definePrompt({
  name: 'pdfSummarizationPrompt',
  input: {schema: PdfSummarizationInputSchema},
  output: {schema: PdfSummarizationOutputSchema},
  prompt: `You are an expert summarizer of PDF documents.\n\nYou will receive a PDF document as a data URI. Your task is to summarize the document and provide a concise summary of the main points.\n\nHere is the PDF document:\n{{media url=pdfDataUri}}`,
});

const pdfSummarizationFlow = ai.defineFlow(
  {
    name: 'pdfSummarizationFlow',
    inputSchema: PdfSummarizationInputSchema,
    outputSchema: PdfSummarizationOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
