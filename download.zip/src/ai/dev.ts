import { config } from 'dotenv';
config();

import '@/ai/flows/pdf-summarization.ts';