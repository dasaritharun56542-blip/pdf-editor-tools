import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { ToolCard } from '@/components/shared/ToolCard';
import { tools } from '@/lib/data';
import { Zap, ShieldCheck, CircleCheckBig } from 'lucide-react';
import { PlaceHolderImages } from '@/lib/placeholder-images';

export default function Home() {
  const heroImage = PlaceHolderImages.find(p => p.id === 'hero-image');

  return (
    <div className="flex flex-col items-center">
      <section className="w-full py-16 md:py-24 lg:py-32">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <h1 className="text-4xl font-extrabold tracking-tighter text-gray-900 sm:text-5xl md:text-6xl">
              Every tool you need to work with PDFs in one place
            </h1>
            <p className="mx-auto mt-4 max-w-[700px] text-lg text-gray-600 md:text-xl">
              Every tool you need to use PDFs, at your fingertips. All are 100% FREE and easy to use! Merge, split, compress, convert, rotate, unlock and watermark PDFs with just a few clicks.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:gap-6 lg:grid-cols-4 xl:grid-cols-5">
            {tools.map((tool) => (
              <ToolCard key={tool.id} {...tool} />
            ))}
          </div>
        </div>
      </section>

       <section className="w-full bg-white py-16 md:py-24">
        <div className="container mx-auto grid grid-cols-1 items-center gap-12 px-4 md:grid-cols-2">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-gray-900">
              Looking for a different tool?
            </h2>
            <p className="max-w-[600px] text-gray-600 md:text-lg">
              We have a wide range of PDF tools to help you with any task. If you can't find what you are looking for, let us know and we might be able to build it for you!
            </p>
            <div className="flex flex-col gap-4 sm:flex-row">
              <Button asChild size="lg">
                <Link href="/tools">View All Tools</Link>
              </Button>
            </div>
          </div>
          <div className="flex justify-center">
             {heroImage && (
                <Image
                    src={heroImage.imageUrl}
                    alt={heroImage.description}
                    width={500}
                    height={350}
                    className="rounded-lg object-cover"
                    data-ai-hint={heroImage.imageHint}
                />
            )}
          </div>
        </div>
      </section>

      <section className="w-full py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl text-gray-900">
              Why Choose PDFToolbox?
            </h2>
          </div>
          <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-3">
            <div className="flex flex-col items-center space-y-3 text-center">
              <div className="rounded-full bg-primary/10 p-4">
                <Zap className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Fast and Easy</h3>
              <p className="text-muted-foreground">
                Our tools are designed to be fast and easy to use. Get your work done in seconds.
              </p>
            </div>
            <div className="flex flex-col items-center space-y-3 text-center">
              <div className="rounded-full bg-primary/10 p-4">
                <ShieldCheck className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Secure</h3>
              <p className="text-muted-foreground">
                We take your privacy seriously. Your files are safe with us and deleted after 2 hours.
              </p>
            </div>
            <div className="flex flex-col items-center space-y-3 text-center">
              <div className="rounded-full bg-primary/10 p-4">
                <CircleCheckBig className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Feature Rich</h3>
              <p className="text-muted-foreground">
                A complete suite of tools to handle all your PDF needs, available for free.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
