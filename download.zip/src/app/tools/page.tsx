import { ToolCard } from "@/components/shared/ToolCard";
import { tools } from "@/lib/data";

export default function ToolsPage() {
  return (
    <div className="container mx-auto px-4 py-12 sm:py-16">
      <div className="mb-12 text-center">
        <h1 className="text-4xl font-bold tracking-tighter text-primary sm:text-5xl">
          All PDF Tools
        </h1>
        <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground md:text-lg">
          Discover our full suite of tools to make your document management seamless and efficient.
        </p>
      </div>
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {tools.map((tool) => (
          <ToolCard key={tool.id} {...tool} />
        ))}
      </div>
    </div>
  );
}
