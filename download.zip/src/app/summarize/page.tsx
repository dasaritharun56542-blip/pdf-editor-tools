import { SummarizeClient } from '@/components/summarize/SummarizeClient';

export default function SummarizePage() {
  return (
    <div className="container mx-auto max-w-4xl px-4 py-12 sm:py-16">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold tracking-tighter text-primary sm:text-5xl">
          AI PDF Summarizer
        </h1>
        <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground md:text-lg">
          Upload your PDF and let our AI provide a concise summary. A Premium feature of PDFToolbox.
        </p>
      </div>
      <SummarizeClient />
    </div>
  );
}
