
"use client";

import { useUser } from '@/context/UserContext';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { ToolCard } from '@/components/shared/ToolCard';
import { tools } from '@/lib/data';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Loader2 } from 'lucide-react';
import { useAuth, useFirestore } from '@/firebase';
import { isSignInWithEmailLink, signInWithEmailLink } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

export default function DashboardPage() {
  const { user, isPremium, isLoading: isUserContextLoading } = useUser();
  const router = useRouter();
  const auth = useAuth();
  const firestore = useFirestore();
  const { toast } = useToast();
  const [isVerifying, setIsVerifying] = useState(true);

  useEffect(() => {
    const completeSignIn = async () => {
      // This effect should only run on the client, and only if auth and firestore are ready.
      if (!auth || !firestore || typeof window === 'undefined') {
        // If services aren't ready, we can't verify, but we shouldn't assume it's not a sign-in link yet.
        // We'll let the effect re-run when services are available.
        return;
      }

      if (isSignInWithEmailLink(auth, window.location.href)) {
        let email = window.localStorage.getItem('emailForSignIn');
        if (!email) {
          // This can happen if the user opens the link on a different device.
          // We can prompt them for their email.
          email = window.prompt('Please provide your email for confirmation');
        }
        if (!email) {
            toast({ title: "Sign-in failed", description: "Email is required to complete sign-in.", variant: "destructive" });
            router.push('/login');
            return;
        }

        try {
          const result = await signInWithEmailLink(auth, email, window.location.href);
          const user = result.user;
          
          const userDocRef = doc(firestore, 'users', user.uid);
          const userDoc = await getDoc(userDocRef);

          if (!userDoc.exists()) {
            const name = window.localStorage.getItem('nameForSignUp') || user.email?.split('@')[0] || `User ${user.uid.substring(0, 5)}`;
            await setDoc(userDocRef, {
              id: user.uid,
              name: name,
              email: user.email,
              isPremium: false,
            });
            toast({ title: "Account Created", description: `Welcome, ${name}!` });
          } else {
             toast({ title: "Login Successful", description: "Welcome back!" });
          }
          
        } catch (error: any) {
          toast({ title: "Sign-in failed", description: error.message, variant: "destructive" });
        } finally {
          // Clean up regardless of success or failure
          window.localStorage.removeItem('emailForSignIn');
          window.localStorage.removeItem('nameForSignUp');
          // Clean the URL by replacing the current history entry
          window.history.replaceState({}, document.title, '/dashboard');
          setIsVerifying(false);
        }
      } else {
         setIsVerifying(false);
      }
    };

    completeSignIn();
  }, [auth, firestore, router, toast]);
  
  useEffect(() => {
    // This effect now correctly waits for verification to finish
    if (!isUserContextLoading && !isVerifying && !user) {
      router.push('/login?redirect=/dashboard');
    }
  }, [user, isUserContextLoading, isVerifying, router]);

  const isLoading = isUserContextLoading || isVerifying;

  if (isLoading || !user) {
    return (
        <div className="container mx-auto flex h-[calc(100vh-8rem)] items-center justify-center px-4 py-12 sm:py-16 text-center">
            <Loader2 className="h-8 w-8 animate-spin" />
        </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-12 sm:py-16">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tighter text-primary sm:text-4xl">
          Welcome back, {user.name}!
        </h1>
        <p className="mt-2 text-lg text-muted-foreground">
          {isPremium ? "You have access to all our Premium tools." : "Ready to get to work? Here are your available tools."}
        </p>
        {!isPremium && (
          <Button asChild className="mt-4 bg-accent hover:bg-accent/90">
            <Link href="/pricing">Upgrade to Premium</Link>
          </Button>
        )}
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-6">All Tools</h2>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {tools.map((tool) => (
            <ToolCard key={tool.id} {...tool} />
            ))}
        </div>
      </div>
    </div>
  );
}
