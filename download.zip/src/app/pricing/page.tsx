
"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Check } from 'lucide-react';
import { useUser } from '@/context/UserContext';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { PaymentModal } from '@/components/pricing/PaymentModal';

const freeFeatures = [
  'Merge PDF',
  'Split PDF',
  'Compress PDF (Basic)',
  'Word to PDF',
  'JPG to PDF',
  'Limited to 1 file at a time',
  'Up to 10MB file size',
];

const premiumFeatures = [
  'All free features',
  'Summarize PDF with AI',
  'PDF to Word',
  'PDF to JPG',
  'Unlimited file processing',
  'Up to 1GB file size',
  'Faster processing speeds',
  'No watermarks',
  'Priority support',
];

export default function PricingPage() {
  const { user, isPremium, upgrade } = useUser();
  const router = useRouter();
  const { toast } = useToast();
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  const handleUpgradeClick = () => {
    if (!user) {
      router.push('/login?redirect=/pricing');
    } else {
      setShowPaymentModal(true);
    }
  };

  const onPaymentSuccess = async () => {
    await upgrade();
    toast({
      title: "Congratulations!",
      description: "You've been upgraded to the Premium plan.",
    });
    router.push('/dashboard');
  }
  
  const handleFreeClick = () => {
    if (!user) {
      router.push('/signup');
    }
  };

  return (
    <>
      <div className="container mx-auto px-4 py-12 sm:py-16">
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold tracking-tighter text-primary sm:text-5xl">
            Choose Your Plan
          </h1>
          <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground md:text-lg">
            Start for free and upgrade when you need more power. Simple and transparent pricing for everyone.
          </p>
        </div>

        <div className="mx-auto grid max-w-4xl grid-cols-1 gap-8 md:grid-cols-2">
          <Card className="flex flex-col">
            <CardHeader>
              <CardTitle className="text-2xl">Free</CardTitle>
              <CardDescription>Perfect for basic PDF tasks.</CardDescription>
              <div className="pt-4">
                <span className="text-4xl font-bold">$0</span>
                <span className="text-muted-foreground">/month</span>
              </div>
            </CardHeader>
            <CardContent className="flex-grow space-y-3">
              <h3 className="font-semibold">Includes:</h3>
              <ul className="space-y-2">
                {freeFeatures.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <Check className="h-5 w-5 shrink-0 text-green-500" />
                    <span className="text-sm text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={handleFreeClick} disabled={!!user}>
                {user ? 'You are registered' : 'Get Started'}
              </Button>
            </CardFooter>
          </Card>

          <Card className="border-primary ring-2 ring-primary flex flex-col">
            <CardHeader>
              <CardTitle className="text-2xl text-primary">Premium</CardTitle>
              <CardDescription>For professionals and teams who need more.</CardDescription>
              <div className="pt-4">
                <span className="text-4xl font-bold">$9.99</span>
                <span className="text-muted-foreground">/month</span>
              </div>
            </CardHeader>
            <CardContent className="flex-grow space-y-3">
              <h3 className="font-semibold">Everything in Free, plus:</h3>
              <ul className="space-y-2">
                {premiumFeatures.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <Check className="h-5 w-5 shrink-0 text-accent" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-accent hover:bg-accent/90" onClick={handleUpgradeClick} disabled={isPremium}>
                {isPremium ? 'You are on Premium' : 'Upgrade to Premium'}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
      <PaymentModal
        open={showPaymentModal}
        onOpenChange={setShowPaymentModal}
        onPaymentSuccess={onPaymentSuccess}
        price={9.99}
        upiId="9110396906@fam"
      />
    </>
  );
}
