import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const faqs = [
  {
    question: "Is it safe to upload my files?",
    answer: "Yes, your security is our top priority. We use SSL encryption for all file transfers. All files are automatically deleted from our servers after 2 hours. We do not read, copy, or analyze your files in any way."
  },
  {
    question: "How do I upgrade to a Premium account?",
    answer: "You can upgrade to a Premium account by visiting our Pricing page and selecting the 'Upgrade to Premium' option. If you are not logged in, you will be prompted to create an account or log in first."
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept all major credit cards, including Visa, Mastercard, and American Express. Our payment processing is handled by Stripe, ensuring your payment information is secure."
  },
  {
    question: "Can I cancel my subscription at any time?",
    answer: "Yes, you can cancel your Premium subscription at any time from your account dashboard. Your subscription will remain active until the end of the current billing period, and you will not be charged again."
  },
  {
    question: "What are the limitations of the free version?",
    answer: "The free version has limitations on file size, the number of files you can process at once, and access to certain premium tools. For unlimited access and advanced features, we recommend upgrading to our Premium plan."
  },
  {
    question: "What happens to my files after I process them?",
    answer: "For your privacy, all uploaded and processed files are permanently deleted from our servers after 2 hours. We do not keep any copies of your documents."
  }
];

export default function FaqPage() {
  return (
    <div className="container mx-auto max-w-3xl px-4 py-12 sm:py-16">
      <div className="mb-12 text-center">
        <h1 className="text-4xl font-bold tracking-tighter text-primary sm:text-5xl">
          Frequently Asked Questions
        </h1>
        <p className="mx-auto mt-4 max-w-[700px] text-muted-foreground md:text-lg">
          Find answers to common questions about PDFToolbox. If you can't find your answer here, feel free to contact us.
        </p>
      </div>

      <Accordion type="single" collapsible className="w-full">
        {faqs.map((faq, index) => (
          <AccordionItem key={index} value={`item-${index}`}>
            <AccordionTrigger className="text-left text-lg font-semibold hover:no-underline">
              {faq.question}
            </AccordionTrigger>
            <AccordionContent className="text-base text-muted-foreground">
              {faq.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
